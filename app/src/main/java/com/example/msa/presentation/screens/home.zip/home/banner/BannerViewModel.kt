package com.example.msa.presentation.screens.home.banner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BannerViewModel @Inject constructor(
    private val repo: BannerRepository
) : ViewModel() {

    // بنبدأ بالكاش على طول: السلايدر بيبان من أول فريم لو فيه بانرات محفوظة.
    private val _banners = MutableStateFlow(repo.cached())
    val banners: StateFlow<List<Banner>> = _banners.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            // null = الشبكة وقعت → نسيب الكاش زي ما هو.
            repo.fetch()?.let { _banners.value = it }
        }
    }
}
