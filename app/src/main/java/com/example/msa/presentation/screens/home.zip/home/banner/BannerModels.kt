package com.example.msa.presentation.screens.home.banner

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * موديلات بانرات الرئيسية — مطابقة لـ BannerModel.swift في الـ iOS.
 */

// MARK: - Response

@JsonClass(generateAdapter = true)
data class BannersResponseDto(
    @Json(name = "data") val data: List<BannerDto>? = null
)

// MARK: - Banner DTO

@JsonClass(generateAdapter = true)
data class BannerDto(
    @Json(name = "id") val id: Int? = null,
    @Json(name = "name") val name: String? = null,
    @Json(name = "media_type") val mediaType: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "thumb_url") val thumbUrl: String? = null,
    @Json(name = "order") val order: Int? = null,
    @Json(name = "starts_at") val startsAt: String? = null,
    @Json(name = "ends_at") val endsAt: String? = null,
    @Json(name = "link") val link: BannerLinkDto? = null,
    @Json(name = "status") val status: BannerStatusDto? = null
)

@JsonClass(generateAdapter = true)
data class BannerLinkDto(
    @Json(name = "type") val type: String? = null,
    @Json(name = "url") val url: String? = null
)

@JsonClass(generateAdapter = true)
data class BannerStatusDto(
    @Json(name = "value") val value: String? = null,
    @Json(name = "label") val label: BannerStatusLabelDto? = null
)

@JsonClass(generateAdapter = true)
data class BannerStatusLabelDto(
    @Json(name = "ar") val ar: String? = null,
    @Json(name = "en") val en: String? = null
)

// MARK: - Domain model

enum class BannerMediaType { IMAGE, VIDEO }

/**
 * البانر بعد التنضيف. أي عنصر مبيعديش الـ mapping (مفيش id أو mediaUrl)
 * بيتشال خالص بدل ما يبان كخانة سودا في السلايدر.
 */
data class Banner(
    val id: Int,
    val name: String,
    val mediaType: BannerMediaType,
    val mediaUrl: String,
    val thumbUrl: String?,
    val order: Int,
    val linkUrl: String?
)

// MARK: - Mapping

fun BannerDto.toDomainOrNull(): Banner? {

    val safeId = id ?: return null
    val safeUrl = mediaUrl?.takeIf { it.isNotBlank() } ?: return null

    val type = when (mediaType?.lowercase()) {
        "video" -> BannerMediaType.VIDEO
        else -> BannerMediaType.IMAGE
    }

    return Banner(
        id = safeId,
        name = name.orEmpty(),
        mediaType = type,
        mediaUrl = safeUrl,
        thumbUrl = thumbUrl?.takeIf { it.isNotBlank() },
        order = order ?: 0,
        linkUrl = link?.url?.takeIf { it.isNotBlank() }
    )
}

fun List<BannerDto>.toDomain(): List<Banner> =
    mapNotNull { it.toDomainOrNull() }.sortedBy { it.order }
