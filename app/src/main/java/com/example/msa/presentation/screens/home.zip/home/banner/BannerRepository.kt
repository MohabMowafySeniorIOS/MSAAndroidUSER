package com.example.msa.presentation.screens.home.banner

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * بيجيب البانرات من الباك اند وبيكاشها محلياً — نفس فكرة BannerService.swift.
 *
 * الكاش مهم: أول ما الشاشة تفتح بنعرض آخر بانرات اتحفظت فوراً بدل ما
 * المستخدم يشوف مكان فاضي لحد ما الريكوست يرجّع.
 */
@Singleton
class BannerRepository @Inject constructor(
    private val api: BannerApi,
    @ApplicationContext context: Context
) {

    companion object {
        private const val TAG = "BannerRepo"
        private const val PREFS_NAME = "msa_home_banners"
        private const val KEY_BANNERS = "cached_banners"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val gson = Gson()

    // MARK: - Cache

    /** آخر بانرات اتحفظت. بترجّع لستة فاضية لو مفيش كاش أو الكاش باظ. */
    fun cached(): List<Banner> = try {

        val json = prefs.getString(KEY_BANNERS, null)

        if (json.isNullOrBlank()) {
            emptyList()
        } else {
            val type = object : TypeToken<List<Banner>>() {}.type
            gson.fromJson<List<Banner>>(json, type) ?: emptyList()
        }

    } catch (t: Throwable) {
        // البانر حاجة تجميلية — مايستاهلش نكراش التطبيق عشانها.
        Log.w(TAG, "cache read failed", t)
        emptyList()
    }

    private fun saveCache(items: List<Banner>) {
        try {
            prefs.edit().putString(KEY_BANNERS, gson.toJson(items)).apply()
        } catch (t: Throwable) {
            Log.w(TAG, "cache write failed", t)
        }
    }

    // MARK: - Fetch

    /**
     * بيجيب البانرات من الشبكة. لو الريكوست فشل بنرجّع null (مش لستة فاضية)
     * عشان الـ ViewModel يفرّق بين "مفيش بانرات فعلاً" و"الشبكة وقعت"،
     * فيسيب الكاش ظاهر بدل ما يخفي السلايدر.
     */
    suspend fun fetch(): List<Banner>? = withContext(Dispatchers.IO) {
        try {
            val items = api.getBanners().data.orEmpty().toDomain()
            saveCache(items)
            items
        } catch (t: Throwable) {
            Log.e(TAG, "fetchBanners error ----> ${t.message}")
            null
        }
    }
}
