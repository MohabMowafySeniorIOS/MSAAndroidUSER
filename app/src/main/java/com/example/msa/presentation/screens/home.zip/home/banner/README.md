# سلايدر البانر — النسخة الأندرويد

ترجمة كاملة لسلايدر الرئيسية بتاع الـ iOS (`BannerSliderView` / `BannerCell` /
`BannerService` / `HomeVC+Banner`) لـ Jetpack Compose.

## الملفات

| الملف | مقابله في iOS |
|---|---|
| `BannerModels.kt` | `BannerModel.swift` |
| `BannerApi.kt` + `BannerRepository.kt` | `BannerService.swift` |
| `BannerModule.kt` | (مفيش — ده Hilt wiring) |
| `BannerViewModel.kt` | (مفيش — الـ iOS بينده الـ service من الـ VC) |
| `BannerSlider.kt` | `BannerSliderView.swift` + `BannerCell.swift` |
| `BannerFullScreen.kt` | `openImageViewer` / `openVideoPlayer` في `HomeVC+Banner.swift` |

---

## خطوات الدمج (٤ خطوات)

### ١. حط الفولدر في مكانه

```
app/src/main/java/com/msa/android/presentation/screens/home/
├── HomeScreen.kt        ← النسخة المعدّلة الموجودة معاك
├── HomeViewModel.kt     ← زي ما هي، متغيّرتش
└── banner/              ← الفولدر ده كله جديد
```

لو الباكدج بتاعك مختلف، غيّر سطر `package` في أول كل ملف.

### ٢. الـ Gradle

```kotlin
dependencies {
    // Pager موجود في foundation نفسه (لازم 1.6.0 أو أحدث)
    implementation("androidx.compose.foundation:foundation:1.6.0")

    // الصور
    implementation("io.coil-kt:coil-compose:2.6.0")

    // الفيديو
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")

    // LifecycleResumeEffect + collectAsStateWithLifecycle
    // ⚠️ لازم 2.8.0 أو أحدث — الأوفرلود بتاعة LifecycleResumeEffect
    //    اللي بتاخد key اتضافت في 2.8.0
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // موجودين عندك أصلاً على الأغلب
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
}
```

وفي `AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

> **لو عندك Coil 3** بدّل `coil.compose.AsyncImage` بـ `coil3.compose.AsyncImage`
> في `BannerSlider.kt` و `BannerFullScreen.kt`.

### ٣. اربط الـ API بالـ Retrofit بتاعك ⚠️ (أهم خطوة)

`BannerModule.kt` بيعمل Retrofit خاص بيه عشان الكود يشتغل لوحده. **إنت
عندك Retrofit متظبط أصلاً**، فالمفروض تمسح الموديول ده كله وتضيف
السطرين دول في الـ `NetworkModule` بتاعك:

```kotlin
@Provides
@Singleton
fun provideBannerApi(retrofit: Retrofit): BannerApi =
    retrofit.create(BannerApi::class.java)
```

كده البانر هيستخدم نفس الـ baseUrl والـ interceptors والتوكن بتوع باقي
التطبيق. وبعدين شوف المسار في `BannerApi.kt`:

- الـ baseUrl بتاعك بينتهي بـ `/api/` → سيب `@GET("banners")`
- الـ baseUrl هو الدومين بس → خلّيها `@GET("api/banners")`

### ٤. خلاص

`HomeScreen.kt` فيها السطر ده تحت الـ `MSATopBar` مباشرة:

```kotlin
HomeBannerSection(
    modifier = Modifier.padding(horizontal = 16.dp),
    height = 150.dp
)
```

مش محتاج أي حاجة تانية — الـ ViewModel بيتحقن لوحده بـ `hiltViewModel()`.

---

## السلوك (مطابق للـ iOS)

| | |
|---|---|
| الصورة | تفضل ٥ ثواني وبعدين يقلب |
| الفيديو | يلوب لحد ما يخلص، والقلبة بتحصل بعد مدته الحقيقية (بحد أقصى ٢٠ ثانية) |
| صوت البانر | مكتوم دايماً، ومش بياخد الفوكس الصوتي فالأغنية اللي المستخدم سامعها متوقفش |
| الغلاف | `thumb_url` بيفضل ظاهر تحت الفيديو لحد أول فريم — مفيش مستطيل أسود |
| شارة الفيديو | فوق على الشمال، بتبان من أول لحظة وبعدين المدة تظهر جنبها |
| الخلفية / الخروج من الشاشة | كل حاجة بتقف (`LifecycleResumeEffect`) |
| المستخدم بيقلب بإيده | التايمر بيقف مؤقتاً وبيرجع لما يسيبه |
| الضغط على صورة | فل سكرين بزووم من 1x لـ 6x + دبل تاب |
| الضغط على فيديو | فل سكرين **بالصوت** وبأزرار تحكم كاملة |
| مفيش بانرات | السلايدر بيختفي هو والمسافات اللي حواليه |
| الشبكة وقعت | آخر بانرات اتحفظت بتفضل ظاهرة (كاش زي `UserDefaults` في iOS) |

## ملاحظات

- **الاتجاه:** السلايدر متثبّت على LTR جوّه (`LocalLayoutDirection`) — زي
  `semanticContentAttribute = .forceLeftToRight` في الـ iOS — عشان ترتيب
  البانرات اللي جاي من الداشبورد ما يتقلبش في الواجهة العربية. العنوان
  جوه البانر بيبقى على الشمال بسبب كده، بالظبط زي الـ iOS. لو عايزه على
  اليمين، شيل الـ `CompositionLocalProvider` من `BannerSlider`.

- **الفلترة بالتواريخ:** الـ iOS مش بيفلتر بـ `starts_at` / `ends_at` ولا
  بـ `status` — بيعرض كل اللي راجع من الباك اند. عملت نفس الحاجة عشان
  الاتنين يبقوا متطابقين. لو عايز تفلتر، المكان هو `List<BannerDto>.toDomain()`
  في `BannerModels.kt`.

- **لو مش قادر ترفّع lifecycle لـ 2.8:** بدّل الجزء ده في `BannerSlider.kt`

  ```kotlin
  var isResumed by remember { mutableStateOf(false) }
  LifecycleResumeEffect(Unit) {
      isResumed = true
      onPauseOrDispose { isResumed = false }
  }
  ```

  بده (شغال على أي إصدار):

  ```kotlin
  val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
  var isResumed by remember { mutableStateOf(false) }
  DisposableEffect(lifecycleOwner) {
      val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
          when (event) {
              androidx.lifecycle.Lifecycle.Event.ON_RESUME -> isResumed = true
              androidx.lifecycle.Lifecycle.Event.ON_PAUSE  -> isResumed = false
              else -> Unit
          }
      }
      lifecycleOwner.lifecycle.addObserver(observer)
      onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }
  ```

- **أولوية اللينك:** في `HomeBannerSection` فيه `linkTakesPriority = false`
  — نفس المتغيّر الموجود في `HomeVC+Banner.swift`. خلّيه `true` لو قررت
  إن البانر المفروض يودّي على صفحة بدل ما يفتح الميديا، وابعت
  `onOpenLink` من `HomeScreen`.
