package com.example.msa.presentation.screens.home.banner

import retrofit2.http.GET

/**
 * إندبوينت البانرات — نفس اللي الـ iOS بينده عليه (EndPoints.banners).
 *
 * ⚠️ لو الـ baseUrl بتاع الـ Retrofit عندك بينتهي بـ "/api/" غيّر السطر
 * اللي تحت لـ "banners" بس. ولو الـ baseUrl هو الدومين الأساسي بس،
 * سيبه بالمسار الكامل. المسار هنا relative — مالوش "/" في الأول عشان
 * ما يمسحش الـ path بتاع الـ baseUrl.
 */
interface BannerApi {

    @GET("banners")
    suspend fun getBanners(): BannersResponseDto
}
