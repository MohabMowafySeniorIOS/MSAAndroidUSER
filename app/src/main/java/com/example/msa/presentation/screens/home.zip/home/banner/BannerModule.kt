package com.example.msa.presentation.screens.home.banner

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

/**
 * موديول البانرات — تم ربطه بالـ NetworkModule الأساسي للمشروع
 * لضمان توحيد الإعدادات (Moshi + OkHttp) وتجنب تكرار الكود.
 */
@Module
@InstallIn(SingletonComponent::class)
object BannerModule {

    @Provides
    @Singleton
    fun provideBannerApi(retrofit: Retrofit): BannerApi =
        retrofit.create(BannerApi::class.java)
}
